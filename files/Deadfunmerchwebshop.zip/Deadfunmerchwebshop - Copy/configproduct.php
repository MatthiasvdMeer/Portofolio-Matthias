<?php
// auteur: Vul hier je naam in
// functie: configuratiebestand

define("DATABASE", "deadfun merch");
define("SERVERNAME", "localhost");
define("USERNAME", "root");
define("PASSWORD", "");

define("CRUD_TABLE", "producten");

?>