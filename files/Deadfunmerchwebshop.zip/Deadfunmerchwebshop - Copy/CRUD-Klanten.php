<?php

include_once 'Functions-Klanten.php';

CrudKlanten();

?>